'use client';

import React, { useState } from 'react';
import { DndProvider, useDrag, useDrop } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';

// Definindo os tipos de componentes
const COMPONENT_TYPES = {
  DIV: 'div',
  TEXT: 'text',
  IMAGE: 'image',
  TWO_DIVS: 'twoDivs',
  THREE_DIVS: 'threeDivs',
  FOUR_DIVS: 'fourDivs',
};

// Componente Draggable para os itens que podem ser arrastados
const DraggableComponent = ({ type, children, generateChildren }) => {
  const [, drag] = useDrag(() => ({
    type,
    item: { type, generateChildren },
  }));

  return (
    <div
      ref={drag}
      style={{
        padding: '10px',
        border: '1px solid #ccc',
        marginBottom: '10px',
        cursor: 'grab',
      }}
    >
      {children}
    </div>
  );
};

// Componente DroppableArea que aceita componentes dentro de si
const DroppableArea = ({
  parentId,
  onDrop,
  children,
  isMainArea,
  isChildArea,
}) => {
  const [, drop] = useDrop(() => ({
    accept: Object.values(COMPONENT_TYPES),
    drop: (item, monitor) => {
      // Se o drop já foi tratado por um filho, sai daqui
      if (monitor.didDrop()) {
        return;
      }
      // Caso deseje impedir drops em subáreas, utilize if (!isChildArea)
      const extraChildren = item.generateChildren
        ? item.generateChildren()
        : null;
      onDrop(item.type, parentId, null, extraChildren);

      // Indica que este drop foi consumido
      return { dropped: true };
    },
  }));

  return (
    <div
      ref={drop}
      style={{
        minHeight: isMainArea ? '400px' : '100px',
        padding: '20px',
        border: isMainArea ? '2px dashed #ccc' : '1px solid #ccc',
        backgroundColor: isMainArea ? '#f4f4f4' : '#fff',
        marginBottom: '10px',
        display: 'flex',
        gap: '10px',
        flexWrap: 'wrap',
      }}
    >
      {children}
    </div>
  );
};

// Componente RenderComponent que vai renderizar os itens dentro da área arrastável
const RenderComponent = ({ component, onDrop, updateComponent }) => {
  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = () => {
        updateComponent(component.id, {
          ...component,
          content: reader.result,
        });
      };
      reader.readAsDataURL(file);
    }
  };

  // Caso o componente seja uma DIV (área de contenção)
  if (component.type === COMPONENT_TYPES.DIV) {
    return (
      <DroppableArea parentId={component.id} onDrop={onDrop} isChildArea={false}>
        {component.children.map((child) => (
          <RenderComponent
            key={child.id}
            component={child}
            onDrop={onDrop}
            updateComponent={updateComponent}
          />
        ))}
      </DroppableArea>
    );
  }

  // Divs compostas com 2, 3 ou 4 áreas
  if (
    component.type === COMPONENT_TYPES.TWO_DIVS ||
    component.type === COMPONENT_TYPES.THREE_DIVS ||
    component.type === COMPONENT_TYPES.FOUR_DIVS
  ) {
    const numberOfDivs =
      component.type === COMPONENT_TYPES.TWO_DIVS
        ? 2
        : component.type === COMPONENT_TYPES.THREE_DIVS
        ? 3
        : 4;

    return (
      <div
        style={{
          display: 'flex',
          gap: '10px',
          border: '1px solid #ddd',
          padding: '10px',
          marginBottom: '10px',
        }}
      >
        {Array.from({ length: numberOfDivs }).map((_, index) => {
          const subId = `${component.id}-div${index}`;
          return (
            <DroppableArea
              key={index}
              parentId={subId}
              onDrop={onDrop}
              isChildArea={true}
            >
              {(component.children || [])
                .filter((child) => child.parentSubId === subId)
                .map((child) => (
                  <RenderComponent
                    key={child.id}
                    component={child}
                    onDrop={onDrop}
                    updateComponent={updateComponent}
                  />
                ))}
            </DroppableArea>
          );
        })}
      </div>
    );
  }

  // Componente de texto
  if (component.type === COMPONENT_TYPES.TEXT) {
    return (
      <div style={{ width: '100%', marginBottom: '10px' }}>
        <textarea
          style={{
            width: '100%',
            height: '150px',
            padding: '10px',
            border: '1px solid #ccc',
            borderRadius: '5px',
            backgroundColor: '#fff',
          }}
          placeholder="Escreva seu texto aqui..."
          value={component.content}
          onChange={(e) =>
            updateComponent(component.id, {
              ...component,
              content: e.target.value,
            })
          }
        />
      </div>
    );
  }

  // Componente de imagem
  if (component.type === COMPONENT_TYPES.IMAGE) {
    return (
      <div style={{ marginBottom: '10px' }}>
        <input type="file" onChange={handleImageChange} />
        {component.content && (
          <div style={{ marginTop: '10px' }}>
            <img
              src={component.content}
              alt="Uploaded"
              style={{
                // Aplica width/height se existirem, senão 300x200 como default
                width: component.width || 300,
                height: component.height || 'auto',
                maxWidth: '100%',
                borderRadius: '4px',
              }}
            />
            {/* Inputs para redimensionar a imagem */}
            <div style={{ marginTop: '10px' }}>
              <label style={{ marginRight: '10px' }}>
                Largura (px):{' '}
                <input
                  type="number"
                  value={component.width || 300}
                  onChange={(e) =>
                    updateComponent(component.id, {
                      ...component,
                      width: parseInt(e.target.value) || 300,
                    })
                  }
                />
              </label>
              <label>
                Altura (px):{' '}
                <input
                  type="number"
                  value={component.height || 0}
                  onChange={(e) =>
                    updateComponent(component.id, {
                      ...component,
                      height: parseInt(e.target.value) || 0, // Se 0, fica 'auto'
                    })
                  }
                />
              </label>
            </div>
          </div>
        )}
      </div>
    );
  }

  return null;
};

// Componente principal da página de construção
const LandingPageBuilder = () => {
  const [components, setComponents] = useState([]);

  // Gerador de IDs
  const generateId = () => Math.random().toString(36).substr(2, 9);

  // Para gerar automaticamente o objeto do tipo "n DIVs compostas"
  const generateDivGroup = (count, type) => ({
    id: generateId(),
    type,
    content: '',
    children: Array.from({ length: count }, () => ({
      id: generateId(),
      type: COMPONENT_TYPES.DIV,
      content: '',
      children: [],
      parentSubId: null,
    })),
  });

  /**
   * handleDrop:
   *  1) type          -> tipo do componente arrastado
   *  2) parentId      -> ID do "pai" onde será inserido (ou null se for raiz)
   *  3) parentSubId   -> se houver subdivisão (por ex., "comp.id-div0")
   *  4) extraChildren -> se for "twoDivs"/"threeDivs"/"fourDivs", vem de generateChildren()
   */
  const handleDrop = (type, parentId = null, parentSubId = null, extraChildren = null) => {
    // Cria o novo componente
    const newComponent = {
      id: generateId(),
      type,
      content: '',
      parentSubId,
      // Se for DIV vazia, inicia com array de children.
      // Se for outro tipo (TEXT, IMAGE, etc.), null.
      children: type === COMPONENT_TYPES.DIV ? [] : null,
    };

    // Se for componente de imagem, aplica um "tamanho padrão"
    if (type === COMPONENT_TYPES.IMAGE) {
      newComponent.width = 300;
      newComponent.height = 0; // 0 → interpretaremos como 'auto'
    }

    // Se for arrastado um "twoDivs"/"threeDivs"/"fourDivs", coloca os filhos gerados
    if (extraChildren?.children) {
      newComponent.children = extraChildren.children;
    }

    // Se for top-level, adiciona direto no array raiz
    if (parentId === null) {
      setComponents((prev) => [...prev, newComponent]);
      return;
    }

    // Caso contrário, percorre recursivamente até achar o componente com id = parentId
    setComponents((prevComponents) => {
      const updateRecursively = (list) =>
        list.map((comp) => {
          if (comp.id === parentId) {
            // Se veio parentSubId, insere com esse subId
            if (parentSubId) {
              return {
                ...comp,
                children: [
                  ...(comp.children || []),
                  { ...newComponent, parentSubId },
                ],
              };
            }
            // Se não, insere como filho direto
            return {
              ...comp,
              children: [...(comp.children || []), newComponent],
            };
          }
          // Continua descendo se houver children
          if (comp.children) {
            return { ...comp, children: updateRecursively(comp.children) };
          }
          return comp;
        });

      return updateRecursively(prevComponents);
    });
  };

  // Atualiza o conteúdo de um componente (texto, imagem, etc.)
  const updateComponent = (id, updatedComponent) => {
    const updateRecursively = (list) =>
      list.map((comp) =>
        comp.id === id
          ? updatedComponent
          : {
              ...comp,
              children: comp.children ? updateRecursively(comp.children) : [],
            }
      );

    setComponents((prev) => updateRecursively(prev));
  };

  return (
    <DndProvider backend={HTML5Backend}>
      <div style={{ display: 'flex', gap: '20px' }}>
        {/* Barra lateral de componentes arrastáveis */}
        <div style={{ flex: 1 }}>
          <h3>Componentes</h3>
          <DraggableComponent type={COMPONENT_TYPES.DIV}>Div</DraggableComponent>
          <DraggableComponent type={COMPONENT_TYPES.TEXT}>Texto</DraggableComponent>
          <DraggableComponent type={COMPONENT_TYPES.IMAGE}>Imagem</DraggableComponent>
          <DraggableComponent
            type={COMPONENT_TYPES.TWO_DIVS}
            generateChildren={() => generateDivGroup(2, COMPONENT_TYPES.TWO_DIVS)}
          >
            Duas Divs
          </DraggableComponent>
          <DraggableComponent
            type={COMPONENT_TYPES.THREE_DIVS}
            generateChildren={() => generateDivGroup(3, COMPONENT_TYPES.THREE_DIVS)}
          >
            Três Divs
          </DraggableComponent>
          <DraggableComponent
            type={COMPONENT_TYPES.FOUR_DIVS}
            generateChildren={() => generateDivGroup(4, COMPONENT_TYPES.FOUR_DIVS)}
          >
            Quatro Divs
          </DraggableComponent>
        </div>

        {/* Área principal de construção */}
        <div style={{ flex: 9 }}>
          <h3>Área de Construção</h3>

          {/* Renderiza todos os componentes "top-level" */}
          {components.map((component) => (
            <RenderComponent
              key={component.id}
              component={component}
              onDrop={handleDrop}
              updateComponent={updateComponent}
            />
          ))}

          {/* Droppable principal (se quiser permitir soltar diretamente aqui) */}
          <DroppableArea onDrop={handleDrop} isMainArea />
        </div>
      </div>
    </DndProvider>
  );
};

export default LandingPageBuilder;

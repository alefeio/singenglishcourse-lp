'use client'

import React, { useState } from "react";
import { useDrag, useDrop } from "react-dnd";
import { Editor, EditorState } from "draft-js";
import "draft-js/dist/Draft.css";

const ItemTypes = {
  DIV: "div",
  TEXT: "text",
  IMAGE: "image",
};

function SidebarItem({ type, label }: { type: string; label: string }) {
  const [{ isDragging }, drag] = useDrag(() => ({
    type,
    collect: (monitor) => ({
      isDragging: !!monitor.isDragging(),
    }),
  }));
  return (
    <div
      ref={drag}
      className={`p-4 bg-gray-200 rounded-md cursor-pointer mb-2 ${
        isDragging ? "opacity-50" : "opacity-100"
      }`}
    >
      {label}
    </div>
  );
}

function DropArea() {
  const [components, setComponents] = useState<any[]>([]);

  const [, drop] = useDrop(() => ({
    accept: [ItemTypes.DIV, ItemTypes.TEXT, ItemTypes.IMAGE],
    drop: (item: any) => {
      const newComponent = { type: item.type, children: [] };
      if (item.type === ItemTypes.TEXT) {
        newComponent["editorState"] = EditorState.createEmpty();
      }
      setComponents((prev) => [...prev, newComponent]);
    },
  }));

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>, index: number) => {
    if (e.target.files && e.target.files[0]) {
      const fileURL = URL.createObjectURL(e.target.files[0]);
      const updatedComponents = [...components];
      updatedComponents[index].image = fileURL;
      setComponents(updatedComponents);
    }
  };

  const renderComponent = (component: any, index: number) => {
    if (component.type === ItemTypes.DIV) {
      return (
        <div
          key={index}
          className="border border-gray-400 p-4 mb-2 bg-gray-100 rounded-md"
        >
          <DropArea />
        </div>
      );
    }

    if (component.type === ItemTypes.TEXT) {
      return (
        <div key={index} className="mb-2">
          <Editor
            editorState={component.editorState}
            onChange={(newState) => {
              const updatedComponents = [...components];
              updatedComponents[index].editorState = newState;
              setComponents(updatedComponents);
            }}
          />
        </div>
      );
    }

    if (component.type === ItemTypes.IMAGE) {
      return (
        <div key={index} className="mb-2">
          {!component.image ? (
            <input
              type="file"
              accept="image/*"
              onChange={(e) => handleFileUpload(e, index)}
              className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100"
            />
          ) : (
            <img
              src={component.image}
              alt="Uploaded"
              className="w-full max-w-xs rounded-md"
            />
          )}
        </div>
      );
    }
    return null;
  };

  return (
    <div
      ref={drop}
      className="w-full min-h-[500px] border border-dashed border-gray-400 p-4 bg-gray-50 rounded-md"
    >
      {components.map((component, index) => renderComponent(component, index))}
    </div>
  );
}

export default function PageBuilder() {
  return (
    <div className="flex h-screen">
      <div className="w-1/4 p-4 bg-gray-100 border-r border-gray-300">
        <SidebarItem type={ItemTypes.DIV} label="Div" />
        <SidebarItem type={ItemTypes.TEXT} label="Texto" />
        <SidebarItem type={ItemTypes.IMAGE} label="Imagem" />
      </div>
      <div className="w-3/4 p-4">
        <DropArea />
      </div>
    </div>
  );
}

import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/firebaseClient';
import { collection, addDoc, getDocs } from 'firebase/firestore';
import formidable from 'formidable';
import fs from 'fs/promises';
import path from 'path';
import { v4 as uuidv4 } from 'uuid';
import { IncomingMessage } from 'http';

export const config = {
  api: {
    bodyParser: false, // Desativa o parser padrão do Next.js para poder usar o formidable
  },
};

const uploadDir = path.join(process.cwd(), 'public', 'banners');
await fs.mkdir(uploadDir, { recursive: true });

export async function POST(req: NextRequest) {
  try {
    console.log('Iniciando o processamento do formulário...');
    
    // Convertendo req (NextRequest) para IncomingMessage, que é compatível com formidable
    const reqObj = new IncomingMessage(req.body as any);
    reqObj.headers = Object.fromEntries(req.headers.entries());

    // Configuração do formidable para processar a requisição
    const form = formidable({
      multiples: false,
      uploadDir,
      keepExtensions: true,
    });

    console.log('Formulário está sendo parseado...');

    const [fields, files] = await new Promise<any>((resolve, reject) => {
      form.parse(reqObj, (err, fieldsResult, filesResult) => {
        if (err) {
          console.error('Erro ao parsear o formulário:', err);
          reject(err);
        } else {
          console.log('Formulário parseado com sucesso');
          resolve([fieldsResult, filesResult]);
        }
      });
    });

    console.log('ESTOU AQUI'); // Esse log agora deve ser alcançado se o parsing for bem-sucedido

    // Renomeia e move o arquivo enviado
    let imageUrl = '';
    if (files.imageFile) {
      const file = files.imageFile;
      const ext = path.extname(file.originalFilename || '').toLowerCase();
      const newFileName = `${uuidv4()}${ext}`;
      const newFilePath = path.join(uploadDir, newFileName);

      await fs.rename(file.filepath, newFilePath);
      // URL local
      imageUrl = `/banners/${newFileName}`;
    }

    // Salva os dados no Firestore
    const docRef = await addDoc(collection(db, 'banners'), {
      title: fields.title || '',
      subtitle: fields.subtitle || '',
      ctaText: fields.ctaText || '',
      ctaColor: fields.ctaColor || '',
      ctaLink: fields.ctaLink || '',
      imageUrl: imageUrl,
    });

    return NextResponse.json({ success: true, id: docRef.id });
  } catch (error: any) {
    console.error('Erro ao criar banner:', error);
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}


// GET: Retorna os banners do Firestore
export async function GET() {
  try {
    const snapshot = await getDocs(collection(db, 'banners'));
    const data = snapshot.docs.map((doc) => ({
      id: doc.id,
      ...doc.data(),
    }));
    return NextResponse.json(data);
  } catch (error: any) {
    console.error('Erro ao buscar banners:', error); // Aqui você verá o erro completo no terminal.
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  reactStrictMode: true,
  // Se precisar permitir imagens de algum domínio externo, etc.
};

export default nextConfig;

'use client';

import React from 'react';

interface ButtonComponentProps {
  text: string;
  backgroundColor?: string; // Cor de fundo
  textColor?: string; // Cor do texto
  fontSize?: string; // Tamanho da fonte
  padding?: string; // Padding
  borderRadius?: string; // Border radius
  width?: string; // Largura opcional
  height?: string; // Altura opcional
  onClick?: () => void; // Função a ser executada ao clicar
}

const ButtonComponent: React.FC<ButtonComponentProps> = ({
  text,
  backgroundColor = 'rgba(0, 122, 255, 1)', // Cor de fundo padrão
  textColor = '#fff', // Cor do texto padrão
  fontSize = '16px', // Tamanho de fonte padrão
  padding = '10px 20px', // Padding padrão
  borderRadius = '5px', // Border radius padrão
  width, // Largura opcional
  height, // Altura opcional
  onClick, // Função de clique opcional
}) => {
  const buttonStyles: React.CSSProperties = {
    backgroundColor,
    color: textColor,
    fontSize,
    padding,
    borderRadius,
    width: width || 'auto', // Se não definido, será ajustado ao tamanho do texto
    height: height || 'auto', // Se não definido, será ajustado ao tamanho do texto
    border: 'none', // Remove borda padrão
    cursor: 'pointer', // Altera o cursor ao passar o mouse
    display: 'inline-block', // Garante que o botão se ajuste ao conteúdo
    textAlign: 'center',
  };

  return (
    <button style={buttonStyles} onClick={onClick}>
      {text}
    </button>
  );
};

export default ButtonComponent;
